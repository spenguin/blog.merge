<?php
/**
	Social Links for footer
*/
<div class="social-links">
	<a href="">Fb</a>
	<a href="">Tw</a>
	<a href="">Rs</a>
	<a href="">Li</a>

</div>

