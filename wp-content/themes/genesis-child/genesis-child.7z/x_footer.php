<?php
/**
	Footer structure
*/
?>
<footer>
	<p>Test</p>
</footer>
<?php
	wp_footer(); 
?>