<?php

namespace Navigation;
/**
	Navigation code
*/

\Navigation\init();

function init()
{
	add_filter( 'walker_nav_menu_start_el', '\Navigation\headerMenuExt', 10, 4 );	

	add_action( 'init', '\Navigation\register_mobile_menu' );
	add_action( 'genesis_before', '\Navigation\add_mobile_nav_genesis' ); 	
}


/**
 * Descriptions on Header Menu
 * @author Bill Erickson
 * @link http://www.billerickson.net/code/add-description-to-wordpress-menu-items/
 * 
 * @param string $item_output, HTML outputp for the menu item
 * @param object $item, menu item object
 * @param int $depth, depth in menu structure
 * @param object $args, arguments passed to wp_nav_menu()
 * @return string $item_output
 *
 *	$item parameters of interest:
 *	- menu_item_parent: (int) determines hierarchy
 *	- classes: (array) classes both from CSS Classes field and provided by WP


 */
function headerMenuExt( $item_output, $item, $depth, $args ) 
{	
	
	if( 'header-menu-1' == $args->menu->slug )
	{	
		if( in_array( 'box-menu', $item->classes ) )
		{
			$item_output = str_replace( '</a>', '<span class="box-top">' . $item->description . '</span></a>', $item_output );
		}
		if( in_array( 'box-item', $item->classes ) )
		{
			
			if( strpos( $item->description, '[' ) !== FALSE )	// Shortcode exists
			{
				$item_output	= do_shortcode( $item->description );
			}
			else
			{
				$item_output	= str_replace( '</a>', '<span class="description">' . $item->description . '</span></a>', $item_output );
			}

		}
	}

	return $item_output;
}


/**
	Register Mobile Menu 
*/
function register_mobile_menu() 
{
	register_nav_menu( 'mobile-menu' ,__( 'Mobile Navigation Menu' ));
}

/**
	Add Mobile Menu location
*/
function add_mobile_nav_genesis() 
{
	wp_nav_menu( array( 'theme_location' => 'mobile-menu', 'container_class' => 'genesis-nav-menu' ) );
}